# Changelog

= 1.5.0 (2024-07-12): =

- Add option to enable redirection to the frontend
- Fix gutenberg issue when siteurl and homeurl are different

= 1.4.7 (2024-04-14): =

- Remove `WooDiscountRules` extension support since it's not needed.
