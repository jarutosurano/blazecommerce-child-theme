export const boxControlDefaults = {
    top: '0px',
    left: '0px',
    right: '0px',
    bottom: '0px',
};